<?php

/**
 * field truyền lên mã hóa
 */
const AUTHORIZACATION = "YXV0aG9yaXphdGlvbg"; //authorization
const CODE_MY_SERVICE = "YWNjb3VudA"; //account
const TOKEN_SERVICE_RECEIVE = "dG9rZW5fc2VydmljZQ"; //token_service;
const CODE = "Y29kZQ"; //code
const CODE_SERVICE = "Code-Service";
const REFERER = "referer";

const IP_MD5 = '957b527bcfbad2e80f58d20683931435'; // ip
/**
 * field thường
 */
const FORMAT_DATE_TIME = "Y-m-d H:i:s";
const FORMAT_DATE = "Y-m-d";
const FORMAT_DATE_TIME_PASSWORD = "Y-m-d_h:m:s";
const AUTHENTICATION = 'authentication';
const AUTHORIZATION = "Authorization";
const BEARER = "Bearer ";
const STATUS = 'status';
const DATA = 'data';
const BODY = 'body';
const VALIDATE = 'validate';
const MESSAGE = 'message';
const CATEGORY = 'category';
const _NULL = 'null';
const BALANCE = 'balance';
const ACCCESS_TOKEN = 'accsess_token';
const ACCESS_TOKEN_COOKIE = 'accsessToken';
const DATE = 'date';
const SERVICE_CHECK = "service_check";
const SIG_VERI_FAILED = "Signature verification failed";
const SPLIT_CURL = "upgrade-insecure-requests";
const KEY_ACCESS_TOKEN = "9a6de362cd27ea135e616473fb650b9a";
const PAGE_SIZE_DEFAULT = 10;
/**
 * Service
 */

const COMMAND_GET_KEY = "encryption.get_primary_key_encryption";
const KEY_CACHE_PRIMARY_KEY_ENCRYPTION = "KEY_CACHE_PRIMARY_KEY_ENCRYPTION";
?>
