<?php
const REQUIRED = "required";
const SUCCESS = 'success';
const FAILED = 'failed';
const MESSAGE_AUTHENTICATION = 'Xác thực thất bại!';
const ADD_DATA_FAILED = 'Thêm dữ liệu that bại!';
const ADD_DATA_SUCCESS = 'Thêm dữ liệu thành công!';
const DELETE_DATA_FAILED = 'Xóa dữ liệu thất bại!';
const DELETE_DATA_SUCCESS = 'Xóa dữ liệu thành công!';
const UPDATE_DATA_FAILED = 'Cập nhật dữ liệu thất bại!';
const UPDATE_DATA_SUCCESS = 'Cập nhật dữ liệu thành công!';
const INTERNAL_SERVER = "Internal Server Error";
const SERVER = "server";
const FORMAT_LENGHT_PASSOWRD = "Mật khẩu không được ngắn hơn 8 kí tự!";
const PERMISSION_DEVICE_FAILED = "Thiết bị hiện chưa có quyền nhận key!";
const KEY_EXPIRED = "Key đã hết thời hạn, xin nhận lại Key mới!";
const VERIFY_KEY = "Đã xác thực key thành công!";
const VERIFY_KEY_FAILD = "Xác thực key thất bại!";
const VALUE_INVLID = "Giá trị đầu vào lỗi!";
const PERMISSION_INVALID = "Không có quyền truy cập vào tài nguyên này!";
const FIELD_EMPTY = "Field không được trống!";
const FIELD_INVALID = "Thông tin đầu vào không chính xác!";
const OUT_OF_KEY = "Key đã hết!";
?>
