<?php
/**
 * field tables
 */
const FIELD_PASSWORD = 'password';
const FIELD_ID = 'id';
const FIELD_USERNAME = 'username';
const FIELD_TIME_CREATE = "time_create";
const FIELD_ID_CATEGORY = 'id_category';
const FIELD_CATEGORY = 'category';
const FIELD_KEY = "key";

const FIELD_CODE = "code";
const FIELD_TOKEN = "token";
const FIELD_ID_ACCOUNT = "id_account";
const FIELD_ID_KEY = "id_key";
const FIELD_TIME_EXPRIED = "time_expried";
const FIELD_ID_SERVICE = "id_service_using";
const FIELD_NAME = "name";
const FIELD_VALUE = "value";
const FIELD_LOGO = "logo";
const FIELD_TIME_REQUEST = "time_request";
const FIELD_DEVICE = "device";
const FIELD_END_POINT = "endpoint";
const FIELD_DESCRIPTION = "description";
const FIELD_MY_SERVICE = "MY_SERVICE";
const FIELD_SERVICES = 'services';
const FIELD_BANK = 'bank';
const FIELD_BRANCH = 'branch';
const FIELD_NUMBER_PHONE = "number_phone";
const FIELD_EMAIL = "email";
const FIELD_ADDRESS = "address";
const FIELD_AVATAR = "avatar";
const FILED_GENDER = 'gender';
const FIELD_BIRTH_DAY = 'birth_day';
const FILED_TOTAL_BALANCE = 'total';
const FILED_CURRENT_BALANCE = 'current';
const FILED_AVAILABLE_BALANCE = 'available';
const FIELD_USED = 'used';
const FIELD_EARNED = 'earned';
const FILED_LOCKED_BALANCE = 'clocked';
/**
 * field other
 */

const FIELD_TIME = 'time';
const FIELD_NAME_SERVICE = "name_service";
const FIELD_TOKEN_V1_SERVICE = "token_v1_service";
const FIELD_CODE_SERVICE = "code_service";
const FIELD_TOKEN_V2_SERVICE = "token_v2_service";
const FIELD_LOGO_SERVICE = "logo_service";
const FIELD_END_POINT_SERVICE = "end_point_service";
const FIELD_CACHE = "CACHE";
const FIELD_BROWSER = 'browser';
const FIELD_IP = 'ip';
const FIELD_INFO = 'info';
const FIELD_GET_ALL = 'get_all';
?>
